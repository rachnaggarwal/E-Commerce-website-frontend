 
 var a=0;
 function openfunction(){
   window.open("https://login-page.rachnaaggarwal.repl.co", "", "width=800,height=500");
 }
 function openfunction2(){
   window.open("https://signup-page.rachnaaggarwal.repl.co/", "", "width=800,height=500");
 }
 function addcart(){
   a++;
   document.getElementById("cart").innerHTML = a;
 }
 function addi1(){
  var x = document.getElementById("i1");
  if (x.style.display === "none") {
   document.getElementById("i1").innerHTML = "Very lightweighted dress,</br> made up of cotten </br>. Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi2(){
    var x = document.getElementById("i2");
  if (x.style.display === "none") {
  document.getElementById("i2").innerHTML = "Indian traditional dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi3(){
      var x = document.getElementById("i3");
  if (x.style.display === "none") {
  document.getElementById("i3").innerHTML = "Indian traditional dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi4(){
      var x = document.getElementById("i4");
  if (x.style.display === "none") {
  document.getElementById("i4").innerHTML = "Summer dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi5(){
      var x = document.getElementById("i5");
  if (x.style.display === "none") {
  document.getElementById("i5").innerHTML = "Indian Kurti dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi6(){
      var x = document.getElementById("i6");
  if (x.style.display === "none") {
  document.getElementById("i6").innerHTML = "Indian Kurti dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg1(){
  var x = document.getElementById("i1a");
  if (x.style.display === "none") {
   document.getElementById("i1a").innerHTML = "Cute birthday dress,</br> made up of cotten </br>. Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg2(){
    var x = document.getElementById("i2a");
  if (x.style.display === "none") {
  document.getElementById("i2a").innerHTML = "Red frok,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg3(){
  var x = document.getElementById("i3a");
  if (x.style.display === "none") {
  document.getElementById("i3a").innerHTML = "Western dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg4(){
      var x = document.getElementById("i4a");
  if (x.style.display === "none") {
  document.getElementById("i4a").innerHTML = "Jumpsuit for 7-14 years,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg5(){
      var x = document.getElementById("i5a");
  if (x.style.display === "none") {
  document.getElementById("i5a").innerHTML = "Night dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg6(){
      var x = document.getElementById("i6a");
  if (x.style.display === "none") {
  document.getElementById("i6a").innerHTML = "5-7 years dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add7(){
  var x = document.getElementById("i7");
  if (x.style.display === "none") {
   document.getElementById("i7").innerHTML = "Party wear for boys,</br> made up of cotten </br>. Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add8(){
    var x = document.getElementById("i8");
  if (x.style.display === "none") {
  document.getElementById("i8").innerHTML = "11-13 years</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add9(){
  var x = document.getElementById("i9");
  if (x.style.display === "none") {
  document.getElementById("i9").innerHTML = "Western dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add10(){
      var x = document.getElementById("i10");
  if (x.style.display === "none") {
  document.getElementById("i10").innerHTML = "XL-XXL size available,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add11(){
      var x = document.getElementById("i11");
  if (x.style.display === "none") {
  document.getElementById("i11").innerHTML = "Available in red, blue, brown</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add12(){
      var x = document.getElementById("i12");
  if (x.style.display === "none") {
  document.getElementById("i12").innerHTML = "L-XL size available,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 
  function add7b(){
  var x = document.getElementById("i7b");
  if (x.style.display === "none") {
   document.getElementById("i7b").innerHTML = "Party wear for men,</br> made up of cotten </br>. Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add8b(){
    var x = document.getElementById("i8b");
  if (x.style.display === "none") {
  document.getElementById("i8b").innerHTML = "Party wear for men,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add9b(){
  var x = document.getElementById("i9b");
  if (x.style.display === "none") {
  document.getElementById("i9b").innerHTML = "Western dress,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add10b(){
      var x = document.getElementById("i10b");
  if (x.style.display === "none") {
  document.getElementById("i10b").innerHTML = "XL-XXL size available,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add11b(){
      var x = document.getElementById("i11b");
  if (x.style.display === "none") {
  document.getElementById("i11b").innerHTML = "Available in red, blue, brown</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add12b(){
      var x = document.getElementById("i12b");
  if (x.style.display === "none") {
  document.getElementById("i12b").innerHTML = "L-XL size available,</br> made up of cotten </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 