 
 var a=0;
 function openfunction(){
   window.open("https://login-page.rachnaaggarwal.repl.co", "", "width=800,height=500");
 }
 function openfunction2(){
   window.open("https://signup-page.rachnaaggarwal.repl.co/", "", "width=800,height=500");
 }
 function addcart(){
   a++;
   document.getElementById("cart").innerHTML = a;
 }
 function addi1(){
  var x = document.getElementById("i1");
  if (x.style.display === "none") {
   document.getElementById("i1").innerHTML = "Black Color </br>Office wear slipper .</br> Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi2(){
    var x = document.getElementById("i2");
  if (x.style.display === "none") {
  document.getElementById("i2").innerHTML = "Floral belly .</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi3(){
      var x = document.getElementById("i3");
  if (x.style.display === "none") {
  document.getElementById("i3").innerHTML = "Black Color </br>Office wear slipper .</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi4(){
      var x = document.getElementById("i4");
  if (x.style.display === "none") {
  document.getElementById("i4").innerHTML = "All sizes are available.</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi5(){
      var x = document.getElementById("i5");
  if (x.style.display === "none") {
  document.getElementById("i5").innerHTML = "All sizes are available.</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addi6(){
      var x = document.getElementById("i6");
  if (x.style.display === "none") {
  document.getElementById("i6").innerHTML = "Floral belly .</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg1(){
  var x = document.getElementById("i1a");
  if (x.style.display === "none") {
   document.getElementById("i1a").innerHTML = "Blue color </br>Sparkle belly.</br>Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg2(){
    var x = document.getElementById("i2a");
  if (x.style.display === "none") {
  document.getElementById("i2a").innerHTML = " Floral Shoes,</br> by Glacier </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg3(){
  var x = document.getElementById("i3a");
  if (x.style.display === "none") {
  document.getElementById("i3a").innerHTML = "Rainbow belly,</br> flexible material </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg4(){
      var x = document.getElementById("i4a");
  if (x.style.display === "none") {
  document.getElementById("i4a").innerHTML = "All sizes available</br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg5(){
      var x = document.getElementById("i5a");
  if (x.style.display === "none") {
  document.getElementById("i5a").innerHTML = "Leather black sandal.</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function addg6(){
      var x = document.getElementById("i6a");
  if (x.style.display === "none") {
  document.getElementById("i6a").innerHTML = "All sizes available</br>Sparkle Belly</br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add7(){
  var x = document.getElementById("i7");
  if (x.style.display === "none") {
   document.getElementById("i7").innerHTML = "Blue color </br>leather shoes.</br>Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add8(){
    var x = document.getElementById("i8");
  if (x.style.display === "none") {
  document.getElementById("i8").innerHTML = "Red Shoes,</br> by Glacier </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add9(){
  var x = document.getElementById("i9");
  if (x.style.display === "none") {
  document.getElementById("i9").innerHTML = "Western shoes,</br> by Air </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add10(){
      var x = document.getElementById("i10");
  if (x.style.display === "none") {
  document.getElementById("i10").innerHTML = "All sizes available</br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add11(){
      var x = document.getElementById("i11");
  if (x.style.display === "none") {
  document.getElementById("i11").innerHTML = "Leather shoes.</br> Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add12(){
      var x = document.getElementById("i12");
  if (x.style.display === "none") {
  document.getElementById("i12").innerHTML = "All sizes available </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 
  function add7b(){
  var x = document.getElementById("i7b");
  if (x.style.display === "none") {
   document.getElementById("i7b").innerHTML = "Leather Shoes,</br> 5-7 years</br>. Made in India";
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add8b(){
    var x = document.getElementById("i8b");
  if (x.style.display === "none") {
  document.getElementById("i8b").innerHTML ="Party wear </br>shoes for kids,</br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add9b(){
  var x = document.getElementById("i9b");
  if (x.style.display === "none") {
  document.getElementById("i9b").innerHTML = "Western Shoes,</br> Rainbow laces </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add10b(){
      var x = document.getElementById("i10b");
  if (x.style.display === "none") {
  document.getElementById("i10b").innerHTML = "All size available,</br> Slipper <br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add11b(){
      var x = document.getElementById("i11b");
  if (x.style.display === "none") {
  document.getElementById("i11b").innerHTML = "White led shoes</br> Available for 3 colors </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 function add12b(){
      var x = document.getElementById("i12b");
  if (x.style.display === "none") {
  document.getElementById("i12b").innerHTML = "All sizes available,</br> Winter shoes </br>. Made in India"; 
    x.style.display = "block";
  } else {
    x.style.display = "none ";
  }
   
 }
 