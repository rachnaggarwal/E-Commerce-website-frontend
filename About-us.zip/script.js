 
 var a=0;
 function openfunction(){
   window.open("https://login-page.rachnaaggarwal.repl.co", "", "width=800,height=500");
 }
 function openfunction2(){
   window.open("https://signup-page.rachnaaggarwal.repl.co/", "", "width=800,height=500");
 }
 function addcart(){
   a++;
   document.getElementById("cart").innerHTML = a;
 }
 