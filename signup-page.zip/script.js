function closefunction() {
  window.close();   // Closes the new window
}
