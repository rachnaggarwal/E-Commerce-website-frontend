Features of my webpage: -
All the basic instructions given for completing industry project are completed.
All the basic instructions given for getting excellence certificate is also completed
My webpage mainly consist of two categories :- footware and clothes for all age group and both the genders
Proper use of javascript, on clicking image you will get desciption
Validated the form in contact page
Made my own logo and icons for maintaining a proper color of website.
This webpage is basically used for online shopping of clothes and footwares with 250 voucher coupon on order above 5000.
I have made sure to maintain proper look and color combination of the website with efficient use of CSS.
it is not a responsive website.
Links added to footer, header as well as main content in few webpages of website