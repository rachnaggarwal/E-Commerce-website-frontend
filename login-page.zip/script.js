function openfunction(){
  window.open("https://e-commerce-site.rachnaaggarwal.repl.co/")
}